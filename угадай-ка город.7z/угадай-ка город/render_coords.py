def render_coords(coords) -> str:
    return ','.join(list(map(str, coords)))